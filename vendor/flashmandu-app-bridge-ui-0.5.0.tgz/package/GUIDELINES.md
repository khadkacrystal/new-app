# Flashmandu App UI Guidelines

How to build an embedded app that reads as part of the Flashmandu admin rather
than as a different product bolted into an iframe.

These rules are derived from the host admin itself — where a rule exists because
the platform does it that way, the precedent is named. Follow them and your app
inherits light/dark, spacing, and interaction behaviour for free.

**Three things that will silently waste your afternoon:**

1. **There is no Tailwind in your app** unless you add it. `w-full`, `space-y-3`,
   `text-sm` resolve to nothing. Use the classes below.
2. **Never set `data-fm-theme`** on `<html>`. Unset, tokens follow the merchant's
   preference. Pinning it ships an app that looks broken for dark-mode users.
3. **Never hardcode a hex colour.** Use a token. A literal is a component that
   cannot go dark — which is how the "edit" action ended up rendering as a
   black-outlined button on a dark surface.
4. **Never hardcode a spacing or size number either.** `padding: 20px` on a card
   is the same class of bug as `#2563eb` on a button: it works on your screen
   and disagrees with every other screen in the product. Use the composition
   tokens in §0.

---

## 0. The design language — every number, and where it came from

The spacing/radius/type scales (`--fm-space-*`, `--fm-radius-*`) say what values
**exist**. They do not say which value a card's padding takes, or how wide the
page gutter is, or how tall a button is — so for the first two versions of this
kit every screen picked its own and they all looked subtly different. That is
what this section fixes.

**Composition tokens** name the value each *part of a page* takes. Component CSS
consumes them; nothing hardcodes them; `test/design-language.test.tsx` fails if a
component drifts off one. Every number below was measured in the host admin, not
chosen — the "Measured in" column is the file it came from, so a future density
change can be re-derived rather than re-guessed.

### 0.1 Layout

| Token | Value | Measured in |
|---|---|---|
| `--fm-page-gutter` | **16px** `< lg` · **24px** `≥ lg` | `layouts/app.blade.php` → `!px-4 lg:!px-6` |
| `--fm-page-top` | **16px** | `layouts/app.blade.php` → `lg:!pt-4` |
| `--fm-page-bottom` | **40px** | `layouts/app.blade.php` → `lg:pb-10` |
| `--fm-content-max` | **none** (uncapped) | Flux `main.blade.php` renders with `container=null` — no cap. Use `.fm-container--reading` (80rem) to opt into a centred column. |
| `--fm-section-gap` | **24px** | host page bodies → `space-y-6` |
| `--fm-stack-gap` | **16px** | inside a card → `space-y-4` |
| `--fm-stack-gap-tight` | **8px** | label/value pairs → `space-y-2` |
| `--fm-bp-lg` | **1024px** | the ONE breakpoint — host command-bar swap |

The kit changes layout at **one** breakpoint: **1024px (`lg`)**. It is the same
1024px the host uses for its command bar and for the mobile-header swap. Do not
introduce a second.

### 0.2 Card

| Token | Value | Measured in |
|---|---|---|
| `--fm-card-padding` | **24px** | Flux `card/index.blade.php` → `p-6` |
| `--fm-card-padding-sm` | **16px** | Flux card `size="sm"` → `p-4` |
| `--fm-card-radius` | **12px** | Flux card → `rounded-xl` |
| `--fm-card-radius-sm` | **8px** | Flux card `size="sm"` → `rounded-lg` |
| `--fm-card-border-width` | **1px** | Flux card → `border border-zinc-200` |
| `--fm-card-shadow` | near-flat, 3% | host cards are flat-to-barely-lifted |
| `--fm-card-header-padding-y` | **16px** | header is shorter than the body inset |
| `--fm-card-gap` | **16px** | grid gap between sibling cards |

### 0.3 Controls (buttons, inputs, selects, segmented control)

**One height per size, shared by every control.** This is the rule that makes a
button dropped next to a search field line up on both edges instead of sitting
two pixels proud. Measured in Flux `button/index.blade.php` and
`input/index.blade.php`.

| Size | Height | Radius | Padding-x (button) | Padding-x (field) | Text | Host equivalent |
|---|---|---|---|---|---|---|
| `md` (default) | **40px** | **8px** | **16px** | **12px** | 14px | `h-10 rounded-lg ps-4` |
| `sm` | **32px** | **6px** | **12px** | 12px | 14px | `h-8 rounded-md px-3` |
| `xs` | **24px** | **6px** | **8px** | — | 12px | `h-6 rounded-md px-2` |

Also fixed: `gap: 8px` between a control's icon and its label
(`--fm-control-gap`, host `gap-2`); `font-weight: 500` (`--fm-control-font-weight`,
host `font-medium`); `16px` glyphs (`--fm-control-icon`).

An **icon-only** button is the same height, squared — 40 / 32 / 24px — never a
button with the label deleted and the padding left behind.

`<textarea>` is the single control that does not take a fixed height: it is
multi-line, so it takes `min-height: 2 × control height` and pays its padding
vertically.

### 0.4 Table density

| Token | Value |
|---|---|
| `--fm-table-cell-padding-y` | **14px** |
| `--fm-table-cell-padding-x` | **16px** |
| `--fm-table-head-padding-y` | **12px** |
| `--fm-table-head-font-size` | **11px**, uppercase, `0.05em` tracking |

### 0.5 Empty state and index footer

| Token | Value | Measured in |
|---|---|---|
| `--fm-empty-padding-y` | **48px** | `livewire/items/index.blade.php:1182` → `py-12` |
| `--fm-empty-icon` | **48px** | same → `h-12 w-12 text-gray-400` |
| `--fm-index-footer-padding-y` | **16px** | `items/index.blade.php:1197` → `py-4` |
| `--fm-index-footer-padding-x` | **16px** | same → `px-4` |

The empty state's glyph takes `--fm-text-muted`, not `--fm-border`: at the
border colour it was a hairline ghost beside the host's `text-gray-400` one.

Pagination has no numbers of its own — it is a row of controls, so it sits on
the `sm` step of the control ladder in §0.3 (32px, 6px radius, weight 500).

One density for `.fm-table`, `.fm-index-table` and the legacy `.app-table`
alias — those three used to disagree (16px vs 14px vs 16/24px cells), which is
why two lists in the same app did not look like the same list.

### 0.6 Using them

```css
/* NO — a number nobody else knows about */
.my-panel { padding: 20px; border-radius: 10px; }

/* YES — the same value every other panel in the product uses */
.my-panel { padding: var(--fm-card-padding); border-radius: var(--fm-card-radius); }
```

### 0.7 Box model

Kit classes are `box-sizing: border-box`, and the kit sets that itself — you do
not need a reset for the kit to lay out correctly. It matters most on
`.fm-container`: `--fm-content-max` is the page's **total** width with the
gutter inside it (`none` by default — see §0.1 — or 80rem when a page opts
into `.fm-container--reading`). Before border-box was declared, a capped
container measured its max-width **plus** two gutters and every page
overflowed sideways inside the embed scroller — invisible in the two apps that
happened to carry a `* { box-sizing: border-box }` of their own, broken in any
app that did not.

The rule is scoped to `[class*="fm-"]`, not `*`. A UI kit that resets the whole
document's box model breaks whatever else the app renders.

### 0.8 Fonts — the one token your app must set

`--fm-font-sans` ships as a **system stack**, because the kit cannot load a
webfont for you. The host admin runs **Instrument Sans**
(`chiya-shots/resources/css/app.css` → `@theme { --font-sans: 'Instrument
Sans', … }`). An app on the system stack is rendering the right spacing, the
right radii and the right colours in the wrong typeface, and that single
difference is most of what "this doesn't feel like an AutoHisab Business app"
means.

Load it once, in your global stylesheet, and point the token at it:

```css
@import url('https://fonts.googleapis.com/css2?family=Instrument+Sans:ital,wght@0,400..700;1,400..700&display=swap');

:root { --fm-font-sans: 'Instrument Sans', ui-sans-serif, system-ui, sans-serif; }
```

---

## 1. Layout

| Need | Class |
|---|---|
| A whole page (chrome + gutter + rhythm) | `<Page>` — start here |
| Page root | `.fm-app-shell` |
| Gutter + max-width content column | `.fm-container` |
| Full-bleed page (map canvas, terminal) | `.fm-container--bleed` |
| Single-column form page | `.fm-container--narrow` (768px) |
| Section = title + one card/table | `.fm-section` |
| Vertical rhythm | `.fm-stack` (`--tight` 8px, default 16px, `--loose` 24px) |
| Two-column form grid | `.fm-form-grid` (`.fm-form-grid--full` to span) |
| Right-aligned row actions | `.fm-row-actions` |

### 1.1 The gutter is yours, not the host's

The host renders the embed iframe inside a `<flux:main class="p-0">` — see
`apps/resources/views/embed/shell.blade.php`, which passes `full-bleed`. The host
therefore contributes **zero** horizontal padding. If your page root is not a
`.fm-container`, your app runs edge to edge while every native admin page beside
it sits on a 16/24px gutter, and it reads as bolted in. This was the single most
visible reason embedded apps "didn't feel like an AutoHisab Business app".

```tsx
<Container>          {/* gutter 16/24px, max-width 1280px, centred, 24px section rhythm */}
  <section />
  <section />
</Container>
```

`.fm-container` is a flex column with `gap: var(--fm-section-gap)`, so **sections
do not add their own top/bottom margins**. A section that sets `margin-bottom`
double-spaces itself against its neighbour.

### 1.2 Page regions — what goes where

An embedded app page has four regions, in this order. Skipping straight to a card
grid with no thought about regions is how screens end up arbitrary.

| Region | Contains | Rules |
|---|---|---|
| **Host chrome** (not yours) | Title, breadcrumbs, page-level actions | `<Page title crumbs actions>`. Never paint a desktop `<h1>` — §2. |
| **Mobile header** | The same title, subtitle and actions, below `lg` | `MobilePageHeader`, drawn by `<Page>` from the same props. |
| **Control strip** | Search, filters, segmented sub-view switcher | Directly under the header, **on the canvas, not in a card**. One row. |
| **Content** | Stat row → primary card/table → secondary cards | Ordered most-summarised first. |

Within Content, the order is fixed: a **stat row** (`.fm-stat-grid`, 2-up below `lg` /
4-up from `lg`) if present, then the page's **one primary object** (the index table,
or the main form card), then supporting cards. Two primary objects on one page
means it should have been two pages or two tabs.

### 1.3 Card or canvas?

The most common composition mistake is wrapping everything in a card, which
produces a page of nested boxes with no hierarchy.

| Put it **in a card** | Put it **on the canvas** |
|---|---|
| A form, or a group of related fields | The filter/search strip |
| A data table (the table wrapper *is* the card) | Tabs / segmented control |
| A discrete, nameable object ("Shipping address") | Page-level empty state |
| A settings group with a heading | Stat tiles (each tile is its own small card) |
| Anything that needs a header, footer, or actions of its own | Section titles |

**Never nest a default card inside a default card.** If you genuinely need an
inner surface, use `<Card size="sm">` (`.fm-card--sm`, 16px/8px) so the inner
padding steps down from the outer instead of matching it — matching padding is
what makes nested cards read as a rendering bug.

---

## 2. `<Page>` — one declaration, and the rule about where a button goes

Every screen is a `<Page>`. It owns the gutter, the max-width, the section
rhythm, the host chrome and the mobile header, so a page never restates any of
them:

```tsx
<Page
  title="Items"
  subtitle="Manage menu items, inventory, and expenses"
  crumbs={[{ label: 'Items' }]}
  actions={[
    { id: 'import', label: 'Import',   icon: 'arrow-up-tray',   onSelect: openImport },
    { id: 'export', label: 'Export',   icon: 'arrow-down-tray', onSelect: openExport },
    { id: 'new',    label: 'New item', icon: 'plus', variant: 'primary', onSelect: createItem },
  ]}
>
  <FilterBar … />
  <IndexShell> … </IndexShell>
</Page>
```

`PageAction.variant` is **optional** — omit it and the action renders as the
neutral style (what `import`/`export` do above); pass `'primary'` for the one
main action (`new item` above) or `'danger'` for a destructive one. `'ghost'`
means the same neutral style as omitting `variant`; `'default'` is a
deprecated spelling of the same thing, kept only so older call sites still
type-check. This union is shared byte-for-byte with `@flashmandu/app-bridge`'s
own `PageActionVariant` — that identity is what makes the wiring below
type-check with **no cast**.

Wire it up **once**, at your app root, so `<Page>` can reach the host:

```tsx
import { usePageChrome } from '@flashmandu/app-bridge/react';
import { configurePageChrome } from '@flashmandu/app-bridge-ui/react';

configurePageChrome(usePageChrome);
```

`<Page>` is the **only** place `usePageChrome` is called in a normal app. Two
callers fight over `SET_PAGE` and the loser's title wins at random. (The kit
does not import the bridge itself — this package is also consumed as a bare
stylesheet by the PHP and Python runtimes, which have no wire protocol.)

**Next.js App Router — do not call `configurePageChrome` at Server Component
module scope.** `app/layout.tsx` is a Server Component by default, and Next's
RSC bundler replaces non-component exports of a `"use client"` package
(`usePageChrome`, `configurePageChrome`) with server-side proxies when they
are required from the server graph. Calling the wiring at module scope there
breaks `next build`'s page-data collection with an opaque
`TypeError: (0, t(...).ll) is not a function`. Do the wiring inside a
rendered Client Component instead:

```tsx
// FAILING — module scope in a Server Component (app/layout.tsx)
import { usePageChrome } from '@flashmandu/app-bridge/react';
import { configurePageChrome } from '@flashmandu/app-bridge-ui/react';
configurePageChrome(usePageChrome); // breaks `next build` page-data collection

export default function RootLayout({ children }) {
  return <html><body>{children}</body></html>;
}
```

```tsx
// WORKING — wired from inside a rendered Client Component
// app/PageChromeBootstrap.tsx
'use client';
import { usePageChrome } from '@flashmandu/app-bridge/react';
import { configurePageChrome } from '@flashmandu/app-bridge-ui/react';

configurePageChrome(usePageChrome);

export function PageChromeBootstrap(): null {
  return null;
}
```

```tsx
// app/layout.tsx (Server Component — just renders the bootstrap)
import { PageChromeBootstrap } from './PageChromeBootstrap';

export default function RootLayout({ children }) {
  return (
    <html>
      <body>
        <PageChromeBootstrap />
        {children}
      </body>
    </html>
  );
}
```

### 2.1 Where does this button go?

Exactly two answers, and the **prop types decide** — not your judgement:

| | **Page-level** | **In-content** |
|---|---|---|
| Acts on | the page as a whole — New, Import, Export, Publish, Save, Delete this record | a *part* of the page |
| Declared as | `actions={[…]}` — **data**, max 4 | a `ReactNode` |
| Drawn by | the **host**: command bar at `lg+`, `MobilePageHeader` below | your content |

In-content, by scope: a view switcher or scoped strip → `controls`
(`.fm-page-actions`) · a card's own action → `<Card action>` / `<Section action>`
· one row's actions → the row's last cell (`.fm-row-actions`) · a selection's
actions → `<BulkActionBar>` · an empty collection's call to action →
`<EmptyState action>`.

`PageAction.label` is a `string`, not a `ReactNode`, because an action has to
survive `postMessage`'s structured clone. That is not a limitation — it is the
enforcement. **You cannot hand the host a rendered button, and you cannot
publish a `controls` node.** Neither mistake is expressible.

Four is the whole page-chrome budget, and it is the host's, not a kit
preference. A fifth action is dropped with a dev warning; an in-app `⋯` menu
holding page-level actions reintroduces page chrome inside the frame, which is
the thing this kit exists to prevent. If you have five, one of them belongs to a
card, a row, or a selection.

### 2.2 There is no desktop `<h1>`, and no way to ask for one

`PageHeader` was **deleted** in 0.3.0 — no shim, no back-compat export.
`PageShell` painted the last one and no longer does; `.fm-page-title`,
`.fm-page-subtitle` and `.fm-page-action` are gone from the stylesheet too,
because leaving a heading class in a published stylesheet leaves the bug
reachable by anyone who types the class name.

There is no `titleHidden` and no `showTitle`. Polaris carries one because
Polaris has two modes: an admin that draws the whole page, and an embedded app
whose title the admin already drew. We only ever have the second, and an option
that can be switched off will be switched off — leaving two stacked headings,
which is the bug that killed `PageHeader` in the first place.

The one `<h1>` in the document is `MobilePageHeader`'s, and it hides at `lg` via
a plain `@media (min-width: 1024px)` rule — never a `matchMedia` check, which
would be wrong on the server and flash on hydration. `Breadcrumbs` follows the
same rule; pass `<Breadcrumbs alwaysVisible />` only when running the app
standalone during development.

### 2.3 `controls` — the in-content strip

`controls` is the host's own header row with the title cell left empty:
top-right, above the filter bar, on the line the heading would have occupied
(`livewire/items/index.blade.php:179`). Use it for things that are **not
commands** — a view switcher, a scoped toggle.

```tsx
<Page title="Categories" controls={<SegmentedControl label="View" … />}>
```

Do not hand-roll it with inline flex styles — that is how three apps end up with
three different gaps above their table.

`Tabs` / `AppTabs` are for **genuine sub-views** of one page, not for page
navigation — the host sidebar and command-bar trail are the navigation. They
render as the host's segmented control.

### 2.4 If you are still calling `usePageChrome` by hand

> **`crumbs` vs `breadcrumbs` — the two are different APIs and both are real.**
> `usePageChrome` takes **`crumbs`** (`flashmandu-app-bridge/src/react/use-page-chrome.ts`,
> `PageChromeInput.crumbs`); `createAppShell` takes **`breadcrumbs`** (a route→label
> map, see below). Passing `breadcrumbs` to `usePageChrome` is silently ignored —
> excess object properties are not a type error on an optional-only interface — and
> the app ships with no trail at all. If your breadcrumb row is empty, check this first.

`<Page>` takes `crumbs` for exactly this reason — it is the bridge's spelling,
and going through `<Page>` means you only have to know it once.

### Route declaration

Declare navigation **once**, in `lib/nav.ts`. Active tab and breadcrumbs derive
from the route; pages pass only a title.

> `createAppShell`'s `PageShell` is **deprecated**. It no longer paints an
> in-page desktop title — its heading goes through `MobilePageHeader` like
> every other page — but its `title` is a `ReactNode`, so it can never publish
> chrome to the host and a page built on it has an empty command bar. It is
> kept for one minor so existing apps keep building. New routes use `<Page>`.

```ts
'use client'; // REQUIRED — see below

import { createAppShell } from '@flashmandu/app-bridge-ui/next';
import { useBridgeTitle } from '@flashmandu/app-bridge/react';

export const { PageShell, AppTabs } = createAppShell({
  tabs: [
    { key: 'home',  href: '/',      label: 'Home' },
    { key: 'items', href: '/items', label: 'Items' },
  ],
  breadcrumbs: {
    '/items':           'Items',
    '/items/[id]':      (id) => `Item #${id}`,
    '/items/[id]/edit': 'Edit',
  },
  useTitle: useBridgeTitle,
});
```

> **The `'use client'` is not optional.** `createAppShell` builds components when
> called, so it must run in the client graph. Evaluated on the server, the
> returned functions are not registered client references and the page dies
> during data collection with a bare `"i is not a function"`. Server Components
> may still import the result.

Render `<UrlSync />` once in the root layout. Path *and* shareable query params
are then mirrored into the host address bar automatically — you do not declare
which params are shareable. Bridge plumbing (`session_token`, `parent_origin`,
`app_id`, …) is never shared; prefix a param `_` to keep it private.

Sidebar entries are a **separate, explicit** declaration in
`flashmandu.app.toml` under `[[nav_items]]`. Adding a page does not add a
sidebar entry; changing them requires re-running `flashmandu-app dev`.

---

## 3. Buttons

### 3.1 Anatomy

Every button is a **control** and takes the §0.3 ladder. `.fm-btn` alone is the
40px base; `.fm-btn--sm` and `.fm-btn--xs` step it down. Nothing else changes a
button's height — no `padding` override, no `line-height` trick.

| | `md` (default) | `sm` | `xs` |
|---|---|---|---|
| Height | 40px | 32px | 24px |
| Radius | 8px | 6px | 6px |
| Padding-x | 16px | 12px | 8px |
| Text | 14px / 500 | 14px / 500 | 12px / 500 |
| Icon-only (square) | 40×40 | 32×32 | 24×24 |
| Glyph | 16px | 16px | 16px |

### 3.2 The variant matrix

| Class | React `variant` | Fill | Border | Use for |
|---|---|---|---|---|
| `.fm-btn--primary` | `primary` | `--fm-primary` (black) | none | The **one** main action on the view |
| `.fm-btn--subtle` | `subtle` | surface | hairline | Secondary actions |
| `.fm-btn--ghost` | `ghost` | transparent | none | Tertiary / cancel / toolbar |
| `.fm-btn--danger` | `danger` | `--fm-danger` | none | Destructive, always confirmed |
| `.fm-btn--view` | `view` | teal tint | teal | Row action — open publicly |
| `.fm-btn--edit` | `edit` | blue tint | blue | Row action — edit |
| `.fm-btn--delete` | `delete` | red tint | red | Row action — delete |

Modifiers: `.fm-btn--sm` · `.fm-btn--xs` · `.fm-btn--icon` (square) ·
`.fm-btn--block` (full width — mobile primary actions and dialog footers only).

**One primary per view.** Two black buttons side by side means neither is the
main action. Everything else is `subtle` or `ghost`.

**Loading** is `<Button loading>`: the button keeps its exact width and height —
it renders a `.fm-spinner--sm` *beside* the label and disables itself. Never swap
the label for "Saving…", which resizes the button and shifts the row.

### 3.3 Placement

| Where | Rule |
|---|---|
| Page primary action | **Not in your page** — it goes to the host command bar via `usePageChrome()` (§2) |
| Card actions | `.fm-card__footer`, right-aligned, secondary first, primary last |
| Row actions | Icon-only `sm`, right-aligned in `.fm-row-actions` |
| Control strip | `sm`, beside the search field, sharing its 40px baseline |
| Mobile header | One `sm` action, no more |

### Row actions carry fixed meaning

Precedent: the host's own table rows (`items/index.blade.php`).

| Class | React | Colour | Means |
|---|---|---|---|
| `.fm-btn--view` / `.btn-action-view` | `variant="view"` | teal | Open/view publicly — leaves the admin surface |
| `.fm-btn--edit` / `.btn-action-edit` | `variant="edit"` | blue | Edit — reversible |
| `.fm-btn--delete` / `.btn-action-delete` | `variant="delete"` | red | Destructive |

These are tinted surface + saturated border + saturated glyph, matching the
host's `flux:button variant="outline" size="sm"` row actions, and they invert
correctly in dark mode because every value is a `--fm-action-*` token.

Do **not** re-map them. A merchant who learns "red = gone" in the admin must
read the same thing in your app. Icon-only, square, always with an accessible
label, right-aligned in `.fm-row-actions`.

```tsx
<div className="fm-row-actions">
  <IconButtonLink label="Open in storefront" variant="view" href={url}><EyeIcon /></IconButtonLink>
  <IconButtonLink label="Edit" variant="edit" href={editUrl}><PencilIcon /></IconButtonLink>
  <IconButton label="Delete" variant="delete" onClick={remove}><TrashIcon /></IconButton>
</div>
```

### Sliders are always black

`Range` (`.fm-range`) draws its track fill, thumb and `accent-color` from
`--fm-primary`. Never restyle a slider to indigo or purple — house rule; the
platform palette is green/black and a purple control reads as another product.

---

## 4. Cards & sections

### 4.1 Anatomy

```html
<div class="fm-card">                         <!-- 24px padding, 12px radius, 1px hairline -->
  <div class="fm-card__header">…</div>        <!-- 16px/24px, muted fill, bottom hairline -->
  <div class="fm-card__body">…</div>          <!-- inherits the card's padding -->
  <div class="fm-card__footer">…</div>        <!-- 16px/24px, muted fill, top hairline, actions right -->
</div>
```

| Part | Padding | Fill | Divider |
|---|---|---|---|
| Card | 24px (`--fm-card-padding`) | `--fm-surface` | 1px `--fm-border`, radius 12px |
| Header | 16px vertical / 24px horizontal | `--fm-surface-muted` | 1px bottom |
| Body | inherits the card's 24px | — | — |
| Footer | 16px vertical / 24px horizontal | `--fm-surface-muted` | 1px top |

The header and footer are **bleed** elements: they negative-margin out to the
card's edges by exactly `--fm-card-padding`, so changing the card's padding
moves the header inset with it. That is why a card's padding must never be
overridden inline — the header would stop lining up with the body.

### 4.2 Sizes

| | Default | `.fm-card--sm` / `<Card size="sm">` |
|---|---|---|
| Padding | 24px | 16px |
| Radius | 12px | 8px |
| Host equivalent | `<flux:card>` | `<flux:card size="sm">` |

### 4.3 `.fm-card--flush`

Padding moves from the card to `.fm-card__body`, and the header/footer stop
bleeding. Use it when the card's content is edge-to-edge — a table, a map, an
image — so the content meets the border with no gutter.

### 4.4 Nesting

A default card inside a default card is a bug: two identical 24px insets read as
a rendering error, not as hierarchy. If you need an inner surface, step down —
`<Card size="sm">`. Do not go a third level; use a divider (`.fm-divider`) or a
`.fm-section-title` instead.

### 4.5 Shadow

Cards are near-flat (3% shadow). The host's own cards are `border`-first, not
`shadow`-first. Do not add `box-shadow` to lift a card off the canvas — if a card
needs more separation it needs a header, not a drop shadow. Elevation is reserved
for things that genuinely float: dropdowns, tooltips, modals.

`.fm-card__accent--{blue|green|teal|orange|primary}` adds a decorative bar.
Purple is deliberately absent — the platform palette is green/black, and purple
reads as another product.

---

## 5. Forms

Every control gets a label. Never rely on a placeholder as the label.

```html
<div class="fm-field">
  <label class="fm-field__label">Name</label>
  <input class="fm-input" />
  <span class="fm-field__hint">Shown under the field.</span>
</div>
```

`.fm-input` · `.fm-select` · `.fm-textarea` · `.fm-checkbox` · `.fm-toggle` ·
`.fm-radio-group` · `.fm-color-picker` · `.fm-file-upload`.

Errors go on `.fm-field__error`, not in an alert far from the field.

**A bare `<select>` is a visible bug.** It renders as an unstyled browser
control next to styled siblings. Always `.fm-select`.

### 5.1 Control sizing

Fields take the same §0.3 ladder as buttons — that is the whole point of the
ladder. A 40px search input and a 40px button next to it agree on both edges.

| | Default | `.fm-input--sm` / `.fm-select--sm` |
|---|---|---|
| Height | 40px | 32px |
| Radius | 8px | 6px |
| Padding-x | 12px (`--fm-field-padding-x`) | 12px |
| Text | 14px | 14px |

`.fm-textarea` is the exception: `min-height` = 2 × 40px, padding paid
vertically at 8px.

### 5.2 Form layout

- Field rhythm inside a card: `.fm-stack` (16px). Label→control inside one
  field: `.fm-field` (8px).
- Two columns only from `lg` (1024px) up, via `.fm-form-grid`; a field that
  needs the full width takes `.fm-form-grid--full`. Never more than two columns — the
  host does not, and a three-column form is unreadable at 1280px inside an
  iframe.
- A form page is `.fm-container--narrow` (768px), not the full 1280px. A
  1280px-wide single-column form has a 60-character line and looks abandoned.
- Save/Cancel live in `.fm-card__footer`, right-aligned, Cancel first.

---

## 6. Index tables

`IndexTable` is the list view for an embedded app. It is a faithful port of the
host's `<x-ui.index-shell>` and behaves identically: the page scrolls normally,
the column headers pin, and a wide table travels sideways from a scrollbar strip
parked just above the pagination.

```tsx
<FilterBar
  search={{ value: q, onChange: setQ, placeholder: 'Search maps' }}
  fields={[{ key: 'status', label: 'Status', type: 'select', defaultValue: 'all', options }]}
  values={filters}
  onChange={(key, value) => setFilters({ ...filters, [key]: value })}
  // The pin — "save this filter as my default". Every host list has it; opt in
  // and the app has it too. `urlKeys` names the query params this list writes,
  // so a SHARED LINK still beats a saved default.
  defaults={{ scope: 'maps', profileId, urlKeys: ['q', 'status'] }}
  viewMode={<SegmentedControl label="View" value={view} onChange={setView} options={views} />}
/>

<IndexTable
  columns={[
    { key: 'name',   label: 'Name',   render: (m) => m.name, sortable: true, pinned: true },
    { key: 'areas',  label: 'Areas',  render: (m) => m.areas, align: 'right' },
  ]}
  data={maps}
  keyExtractor={(m) => m.id}
  selectable
  sort={sort}
  onSortChange={setSort}
  bulkActions={[{ key: 'delete', label: 'Delete', destructive: true, onAction: removeMany }]}
  loading={isLoading}
  emptyState={<EmptyState title="No maps yet" action={<Button>New map</Button>} />}
  footer={<Pagination current={page} total={pages} onChange={setPage} />}
/>
```

### Rules you must not break

- **Never wrap the table in `overflow-x: auto` / `overflow: auto`.** That is not
  a style preference. `overflow-x: auto` computes `overflow-y` to `auto`, which
  turns the wrapper into a scroll container; the sticky `<thead>` then resolves
  against *it* instead of the window, and with no height bound there is no
  scroll range at all — so the header never pins. (Measured in the host: it ran
  off to −1933px instead of parking at its offset.) The shell's viewport uses
  `overflow-x: clip`, the one pairing that keeps `overflow-y: visible`.
- **Sorting is controlled.** `sort` + `onSortChange` report intent; the data
  stays external (server-sorted, usually). The table never reorders rows itself.
- **Pin at most one data column** with `pinned: true`. It counter-translates by
  the *overshoot* only, so it slides with its row and then holds at the edge —
  what `position: sticky; left: 0` would do in a real scrollport. When a column
  is pinned, the checkbox column pins with it automatically.
- **Do not add scroll handlers of your own.** The shell writes CSS custom
  properties through refs and performs **zero React renders while scrolling**.
  A `useState` in that path silently costs a render per scroll frame.

`IndexShell` is available on its own if you need the same chrome around
something that is not a table.

### 6.1 Density

One density, everywhere. `.fm-table`, `.fm-index-table` and the legacy
`.app-table` alias all consume the same four tokens — they used to disagree
(16px vs 14px vs 16/24px cells), which is why two lists in one app read as two
different products.

| Part | Value |
|---|---|
| Body cell | **14px** vertical / **16px** horizontal, `vertical-align: middle` |
| Header cell | **12px** vertical / **16px** horizontal |
| Header type | **11px**, 600, uppercase, `0.05em` tracking, muted |
| Row divider | 1px `--fm-border`; last row has none |
| Footer strip | 12px / 16px, top hairline |
| Select column | 44px wide |
| Empty state | 48px vertical |

The shell itself is a **card**: `--fm-card-radius` (12px),
`--fm-card-border-width`, `--fm-card-shadow`. A table therefore does not need —
and must not have — a `.fm-card` wrapped around it. That would produce a 24px
inset between the card border and the table border and two visible corner radii.

### 6.2 The filter bar is ONE segmented well

The single most-reported "this doesn't look like the admin" was the filter
strip, and the reason was structural rather than cosmetic: the kit used to draw
a `display: flex; gap: 8px` row containing a separately-bordered `.fm-input`,
while the host draws **one** bordered box with its parts divided by internal
hairlines. Two boxes with a gap between them is a different widget, at any
spacing.

Anatomy, left to right, all one `rounded-lg border bg-surface shadow-sm` well:

```
┌───────────────────────┬────────────────────────────┬───┬─┬──────┐
│ ⌥ Filter  (3) ▾       │ search…                    │ × │ │  📌  │
└───────────────────────┴────────────────────────────┴───┴─┴──────┘
   border-right ↑                          borderless      ↑ border-left
```

| Part | Class | Measured in `filter-bar.blade.php` |
|---|---|---|
| The well | `.fm-filter-bar__group` | `:292` — `flex-1 rounded-lg border bg-white shadow-sm` |
| Filter trigger | `.fm-filter-bar__filter` | `:297` — control height, `px-3`, **right** hairline, left corners rounded |
| Active count | `.fm-filter-bar__filter-count` | `:301` — inverted 11px pill |
| Search box | `.fm-filter-bar__search-input` | `:315` — `h-10 px-3`, **`border-0 bg-transparent`** |
| Clear × | `.fm-filter-bar__clear-search` | `:318` — 16px glyph on a `p-1.5 rounded-md` inset |
| Pin | `.fm-filter-bar__pin` | `:337` — **left** hairline, right corners rounded, green when set |
| Trailing slot | `.fm-filter-bar__trailing` | `:350` — view switcher / page actions, **outside** the well |
| Chip row | `.fm-filter-chips` | `:475` — a second row 8px under the well |

Rules that follow from it:

- **The search input never carries a border of its own.** A `.fm-input` inside
  the bar draws a box inside a box.
- **Segments are divided by borders, never by gaps.** A gap lets the canvas
  show through the well.
- **Only the two end segments are rounded**, and only on their outer corners.
- **The chip row renders only when a chip exists** (`:474`). A search term
  clears itself with its own ×; a row containing nothing but "Clear all" is a
  shape the host never draws.
- **The pin appears only while a filter is active** (`:337`) — including an
  active search term, which is why the search key is in the snapshot.

Every number is a `--fm-filter-*` / `--fm-text-eyebrow` token (§0), and
`test/design-language.test.tsx` fails on any drift off one.

The one deliberate deviation from the host: the well takes a `:focus-within`
ring. The host's input is `focus:ring-0` and shows no focus at all, which is a
WCAG 2.4.7 failure the kit is not going to reproduce.

---

## 7. Empty & loading states

Never render an empty table body — use `EmptyState` with an icon, a sentence
explaining what would appear here, and the action that creates the first one.

### Skeleton-first, always

Every route and every table paints a skeleton **before** its data arrives. No
embedded route may show a blank pane. A click with no response reads as a
broken app.

| Situation | Use |
|---|---|
| Whole route, first paint | `<SkeletonPage />` |
| A table waiting on rows | `<IndexTable loading />` or `<SkeletonTable />` |
| A block of copy | `<SkeletonText lines={3} />` |
| A submit in flight | `<Button loading>Saving…</Button>` |

Skeletons preserve layout so nothing jumps, and they stop animating under
`prefers-reduced-motion`. Reserve space for anything async (`aspect-ratio` on
media) to avoid layout shift.

---

## 8. Accessibility

The kit does the hard parts; do not undo them.

- **Modal** traps focus (Tab / Shift+Tab wrap inside the dialog), closes on
  Escape, is labelled from its title, and hands focus back to whatever opened
  it. Never use `window.confirm()` — the app frame's `sandbox` omits
  `allow-modals`, so a blocked `confirm()` silently returns `false` and your
  action never runs. Use `useConfirm()`.
- **Dropdown** is the WAI-ARIA menu-button pattern: a real `<button>` trigger
  with `aria-haspopup` / `aria-expanded`, `role="menu"` items with roving
  focus, Arrow/Home/End navigation, and Escape returning focus to the trigger.
- **ControlledTabs** is the tabs pattern: `tablist` / `tab` / `tabpanel`,
  roving `tabindex` (only the selected tab is in the tab order), and arrow-key
  selection. `SegmentedControl` is a labelled group of `aria-pressed` buttons.
- **IndexTable** puts `aria-sort` on sortable headers, gives every checkbox an
  accessible name, and marks the body `aria-busy` while loading.
- Every icon-only button takes a `label` — it becomes both `aria-label` and the
  tooltip. There is no way to render one without a name.

---

## 9. Feedback

| Need | Use |
|---|---|
| Inline status | `.fm-badge--success/warning/danger/info` |
| Block message | `.fm-callout--info/success/warning/danger` |
| Transient confirmation | `useToast()` from `@flashmandu/app-bridge/react` |
| Hover explanation | `.fm-tooltip-wrapper` + `.fm-tooltip` |

Toast for "it worked". Callout for "here is something you must read". Never a
`window.alert()`.

---

## 10. Motion

Transitions use `--fm-transition` (150ms ease). Motion should explain a spatial
relationship, never decorate.

- Drilling into a region: animate the pan/zoom so the user keeps their bearings.
  An instant jump destroys the parent→child relationship.
- First paint: never animate. It is just a delay before the user can act.
- Respect `prefers-reduced-motion`.

---

## 11. Dark mode

`tokens.css` ships both themes. If you only use tokens, you are already done.

- OS preference by default; `[data-fm-theme="light"|"dark"]` pins it.
- Test both. The failure mode is invisible in the theme you happen to develop in
  — a hardcoded near-black "primary" button looked fine in light and vanished
  into the background in dark.
- Tinted surfaces need a translucent fill in dark, not the light-mode pastel:
  see the `--fm-action-*` tokens for the pattern.

---

## 12. Non-JS runtimes

The CSS class contract — not the React components — is the portable surface.
PHP, Python and plain-HTML apps get the identical look by rendering the same
class names server-side. **`dist/index.css` is the ONE sanctioned import** —
it bundles `fonts.css` + `tokens.css` + `components.css` in that order:

```html
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@flashmandu/app-bridge-ui/dist/index.css">
```

or `loadStyles()` from the package root. Everything in §§1–11 applies unchanged.

**Do not import `tokens.css` and `components.css` directly.** `tokens.css`
names `--fm-font-sans: 'Instrument Sans', …` but the `@font-face` rules that
name resolves to live in `fonts.css`; importing the other two files without it
silently falls back to the system font. `index.css` exists so this cannot
happen — import it, nothing else.

**`index.css` (and the files it bundles) is the whole contract, and
`components.css` contains nothing beyond it.** Every selector in it starts
with `.fm-`, so it can be dropped into a page you do not fully own without
restyling anything that is not already asking for the kit. That is enforced,
not merely intended (`test/design-language`).

The unprefixed aliases that used to sit alongside them — `.btn-primary`,
`.card-header`, `.app-table`, `.modal-backdrop`, `.sortable-ghost` … — are a
third, **optional** file:

```html
<link rel="stylesheet" href="…/dist/legacy.css">   <!-- only if you render them -->
```

Import it last, and only if your markup already uses those names. `.sortable-*`
is the reason it is opt-in: SortableJS applies those classes at runtime, so
importing them restyles every drag-and-drop list in the page whether or not the
kit put them there. New markup should use the `.fm-*` equivalent listed at the
top of `legacy.css`.

### 12.1 Stacking: use the ladder, never a number

Anything the kit floats sits on a named rung declared in `tokens.css`:

| Token | Value | What rides it |
|---|---|---|
| `--fm-z-base` | 0 | in-flow content |
| `--fm-z-raised` | 10 | a lift within the page — sticky `<thead>`, an overlapping pagination cell |
| `--fm-z-sticky` | 20 | page furniture pinned to an edge — the bulk-actions bar |
| `--fm-z-popover` | 30 | anchored overlays owned by a section — the filter panel and per-filter popovers |
| `--fm-z-drawer` | 40 | an edge-anchored panel over the page |
| `--fm-z-modal` | 50 | the modal scrim, and dropdown menus (a menu inside a dialog must clear it) |
| `--fm-z-toast` | 70 | transient confirmations, above a modal |
| `--fm-z-tooltip` | 100 | never occluded |

An embedding app that has chrome of its own **sets the rung, not the selector**.
The host admin's fixed command bar is z-30 and must stay above a page popover,
so it declares `--fm-z-popover: 20` once on `:root`; it does not restate
`.fm-filter-bar__panel`. Writing a literal `z-index` on an `.fm-*` element is
the same category of mistake as writing a literal padding on one.

---

## 13. One component, three runtimes — where the source of truth lives

The host admin renders its list chrome in **Blade + Tailwind utilities**
(`packages/flashmandu/ui-components/.../filter-bar.blade.php`). The bridge UI
renders it in **React + `.fm-*` classes**. SDK apps render whichever of the two
they are built in. "Make it the same component everywhere" therefore has two
possible readings, and only one of them is real.

**What cannot be shared:** the markup. Blade's bar is a Livewire component —
its state lives in `$wire`, its filters are a PHP `filterState()` schema, and it
opens popovers with Alpine. React's is a controlled component with props and
`useState`. Neither can import the other. Anyone promising "one component" at
this layer is promising a rewrite of the host admin.

**What can and does get shared:** the **CSS class contract** (§12) — and it is
the layer that actually carries the look. `dist/components.css` is a plain
stylesheet with no framework in it; any runtime that emits `class="fm-…"` gets
the identical bar.

**So: the rule is one stylesheet, two thin markup implementations, pinned to
one measured spec.**

| Layer | Shared? | Owner |
|---|---|---|
| Geometry (sizes, radii, spacing, colour) | **Yes — literally one file** | `tokens.css` + `components.css` |
| Class names / DOM anatomy | Yes, by contract | §6.2's table |
| Markup + state | No | Blade in the host, React in the kit |
| Enforcement | — | `test/design-language.test.tsx` |

Concretely, when the bar changes:

1. Change the **token**, never a component's number.
2. Update **§6.2's anatomy table** with the host line it was measured at.
3. Update the assertion in `test/design-language.test.tsx` in the same commit —
   the number now exists in exactly one place that can fail.

### 13.1 The filter bar is now converged — this is the pattern to copy

The end state described above has shipped for the **filter bar**. The host no
longer draws it in Tailwind utilities:

- `resources/css/vendor/app-bridge-ui/{tokens,components}.css` in the host is
  generated from this repo's `dist/` by `scripts/sync-bridge-ui-css.mjs` and
  imported into `resources/css/app.css` with `layer(components)`.
- `packages/flashmandu/ui-components/.../filter-bar.blade.php` emits
  `.fm-filter-bar*`, `.fm-filter*`, `.fm-filter-chip*`, `.fm-input` and nothing
  else. Alpine, `$wire` and the filter schema are untouched.
- `tests/Unit/FilterBarClassContractTest.php` in the host is the mirror of the
  CLI repo's `tests/templateStyles.test.ts`: it fails if any element carrying an
  `.fm-*` class also carries a Tailwind utility for padding, size, radius,
  border, background, type scale, colour, flex or position.

**The rule, stated once: geometry lives in exactly one file. Blade and React are
two thin markup layers over it.** A pixel that needs to change is a token in
`tokens.css`, never a utility in a template and never a number in a component.

Converting the next component means: emit the classes, delete the utilities,
extend the host guard's anatomy list, and re-run the sync script. It does not
mean adding a class to this repo to match whatever the host currently looks
like.

The **index shell** followed (37 host pages). It also settled how a host with a
palette of its own joins the contract, which is worth stating because every
later component hits it:

> **The host states its THEME; the kit states everything else.** The kit's
> neutrals are slate, the admin's are Tailwind `gray`, and a converted
> component was drawing a slate hairline three pixels from a gray one — in dark
> mode, a whole surface off. The host now pins `--fm-surface`,
> `--fm-surface-muted` and `--fm-border` to its own ramp once in `app.css`, the
> same way it pins `--fm-z-popover`. Sizes, radii and spacing are never
> restated there. With the theme pinned, the conversion was **pixel-identical**:
> 16/16 Chromium screenshot pairs at {1280×800, 375×812} × {light, dark} ×
> {narrow, wide-scrolled} × {with, without a paginator} diffed to zero.

The lesson generalises: a colour difference at conversion time is a THEME
statement the host has not made yet, not a reason to fork a rule.

### 13.1.1 What is left, ranked

Ranked by consumers × how much geometry is currently hand-written:

| # | Component | Host consumers | Why it is where it is |
|---|---|---|---|
| 1 | **Pinned column / rail interior** (`[data-pinned-col]`) | 37, via the shell | The shell converted but its INTERIOR did not: the host still owns `[data-index-rail] [data-pinned-col]` in `app.css`, with its own z-values (5/25 vs the kit's 2/4), its own 6px edge shadow vs the kit's 12px, and `--index-pinned-bg` fallbacks. Two implementations of one behaviour, one of which the kit already ships. Smallest real gap left. |
| 2 | **Index table** (`.fm-index-table`) | ~37 `<table>`s | The kit has the whole anatomy — head, cell density, row hover, empty row. But each page hand-writes its `<thead>`/`<td>` utilities INLINE, so this is 37 templates rather than one, and the `sticky top-0 lg:top-14 z-10` head offset is host-only (the iframe has no command bar). Highest value, highest cost; do it page-group by page-group behind the existing `IndexShellRolloutGroup*` split. |
| 3 | **Row actions** (`.fm-row-actions` + `.fm-btn--icon`) | ~30 index pages | The kit's row-action colour contract is already written and already token-driven; the host repeats a `flex flex-nowrap items-center justify-end gap-2` cell plus per-verb colours in every template. Mechanical, and `ButtonConsistencyGroup*Test` already fences the shape. |
| 4 | **Bulk-actions bar** (`.fm-bulk-bar`) | ~8 | Small surface, already on `--fm-z-sticky`, but only a handful of pages have one. |
| 5 | **Empty state** (`.fm-empty`) | ~37 | Tokens exist and were measured from `items/index.blade.php`; the copy differs per page, so it is 37 small edits for one card of geometry each. |
| 6 | **Pagination** (`.fm-pagination__*`) | all of them | Blocked, not deprioritised: the host renders Laravel's Tailwind paginator view, so converting it means vendoring a paginator template rather than editing an admin one. |

### 13.2 Three things the host had to work around — now fixed here

Found while converting the filter bar. Each was a place the contract could not
express something, so the host compensated on its own side. All three are
closed; this is the record of what they were and where they landed.

1. **`.fm-filter__option` had no selected state.** The host's select popover
   marks the current option with a tint + heavier weight; React used only a
   radio glyph. The Blade emitted `.fm-filter__option.is-active` — the same
   convention as `.fm-dropdown-item.is-active` and `.fm-tab.is-active` — and
   **no rule defined it**, so a selected option showed only its check mark.
   → `components.css` now styles `.fm-filter__option.is-active`
   (`background: var(--fm-surface-muted); font-weight: 600`), declared AFTER
   `:hover` because the two have identical specificity and the tint must
   survive the pointer leaving. React emits the class too, on both the select
   button and the checked multiselect label, so the two runtimes mark a
   selection the same way.
2. **Overlay z-index was hard-coded, not tokenised.** `.fm-filter-bar__panel`
   and `.fm-filter__popover` shipped `z-index: 30`; the host's fixed command
   bar is also z-30 and must stay on top, so `app.css` restated both selectors
   at 20 — a list that had to grow every time the kit floated something new.
   → `tokens.css` now publishes a **named stacking ladder** (see §12):
   `--fm-z-base 0 · raised 10 · sticky 20 · popover 30 · drawer 40 · modal 50 ·
   toast 70 · tooltip 100`. The values are the ones the kit already shipped —
   this is a tokenisation, not a re-layering — and every floating rule consumes
   a rung. The host now sets `--fm-z-popover: 20` on `:root` and deletes its
   selector override.

   Named rather than ordinal (Polaris uses 13 anonymous steps) because every
   stacking bug this platform has had was "which of these two wins", and an
   ordinal answers that only if you already know each surface's rank. The
   index shell's internal 2/3/4/5 is deliberately off the ladder: it orders
   cells against each other inside one card, not surfaces against the page.
3. **`dist/components.css` also shipped ~50 unprefixed legacy aliases** —
   `.btn-primary`, `.card-header`, `.drag-handle`, `.sortable-ghost`,
   `.modal-backdrop`, `.filter-pill`, … Those are not part of the §12 contract
   and they collide with real host markup (`.sortable-*` is applied at runtime
   by SortableJS on a dozen admin screens), so the host's sync script stripped
   every non-`.fm-` rule before vendoring.
   → They now live in **`dist/legacy.css`**, a separate entry point
   (`@flashmandu/app-bridge-ui/legacy.css`). `components.css` is contract-only
   and can be imported verbatim; the host's sync script no longer filters, it
   only asserts. The aliases are unchanged and still token-driven, because
   **interactive-map renders them today** (`AreaTree` — the sortable category
   tree — and `DashboardHome`'s `btn-icon-action btn-edit` row actions); an app
   that uses them adds one import. The file is frozen: fixes yes, new aliases
   never.

Also note: the host drops `tokens.css`'s `@import "./fonts.css"` because it
already self-hosts Instrument Sans. `--fm-font-sans` resolves against the face
the page has loaded.

### 13.3 Until the packages are published

The host cannot `npm install` this package: it is unpublished, and the host's
Docker asset stage runs a bare `npm ci` with no credentials for a private git
dependency. So the host **vendors a generated copy** and guards it with a
`--check` mode that fails when a developer with both repos checked out lets the
copy go stale. That guard is silent in CI, where the kit is absent — which
means a kit release can still land without the host noticing.

**Publishing `@flashmandu/app-bridge-ui` to npm (or a private registry) removes
the last manual step**: the host's two `@import` lines become
`@import '@flashmandu/app-bridge-ui/dist/tokens.css'` and the vendored files and
sync script are deleted. Until then, a kit release is not complete until the
host's sync script has been re-run.

Until then, **the kit's numbers are derived from the host and the host is
ground truth.** Never "fix" a difference by changing the kit's token to
whatever the app happened to look like.
